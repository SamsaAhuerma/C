#include<stdio.h>


int main()
{
          int x,y,c;
          
          printf("Dar un valor para\n");
          printf("x= ");
          scanf("%d", &x);
          printf("y= ");
          scanf("%d", &y);
          
          c=x;
          printf("El valor de x= %d\n", c+1);
          printf("Y el valor de y= %d\n", c+y);
          
          return 0;
          }


          
          
