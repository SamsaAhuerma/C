#include<stdio.h>
/*Ejercicio 5-a*/
/*Programa h*/
int main()
{
int i;
          printf("Dar valor a i\n");
          printf("i= ");
          scanf("%d", &i);
          
          printf("Entonces nos queda\n");
          
          while (i != 0) {
              i= i-1;
          
          printf("i= %d\n",i);
          }
          
          return 0;
          }
