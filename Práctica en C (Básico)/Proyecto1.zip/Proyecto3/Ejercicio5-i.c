#include<stdio.h>
/*Ejercicio 5 *Programa i*/
int main()
{
int i;
          printf("Dar valor a i\n");
          printf("i= ");
          scanf("%d", &i);
          
          printf("Entonces nos queda\n");
          
          while (i != 0) {
              i=0;
          
          printf("i= %d\n",i);
          }
          
          return 0;
          }
          
          
