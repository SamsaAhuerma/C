/*Ejercicio 3*/
#include <stdio.h>

/*Ejercicio 6-c*/

void imprimeHola(void)
{
          printf("Hola");
          }

void imprimeChau(void)
{         
          printf("Chau");
          }

int main(void){
          imprimeHola();
          printf("\n");
          imprimeHola();
          printf("\n");
          imprimeChau();
          printf("\n");
          imprimeChau();
          return 0;
          }
